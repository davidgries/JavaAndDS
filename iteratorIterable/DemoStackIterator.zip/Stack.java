import java.util.EmptyStackException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/** An instance is a stack */
public class Stack<E> implements Iterable<E> {
	private E[] b;  // stack values are b[0..h-1],
	private int h;  // with b[h-1] at the top

	/** Constructor: a stack of at most m values */
	@SuppressWarnings("unchecked")
	public Stack(int m) {
		b= (E[]) new Object[m];
	}

	/** Push e onto the stack. if there is no room,<br>
	 * Throw a RuntimeException("no space") */
	public void push(E e) {
		if (h == b.length)
			throw new RuntimeException("no space");
		b[h]= e;
		h= h + 1;
	}

	/** Pop and return the top stack value. Throw an<br>
	 * EmptyStackException if the stack is empty. */
	public E pop() {
		if (h == 0) throw new EmptyStackException();
		h= h - 1;
		return b[h];
	}

	/** = size of the stack */
	public int size() {
		return h;
	}

	/** = an Iterator for enumerating the Stack, from top to bottom. */
	public @Override Iterator<E> iterator() {
		return new StackIterator();
	}

	/** An instance is an iterator over the stack<br>
	 * elements, from top to bottom. */
	private class StackIterator implements Iterator<E> {
		int n; // b[n] is the next element to enumerate
			   // (n == -1 means there are no more to enumerate)

		/** Constructor: an iterator over the stack elements,<br>
		 * from top to bottom. */
		public StackIterator() {
			n= h - 1;
		}

		/** = there is another element to enumerate */
		public @Override boolean hasNext() {
			return 0 <= n;
		}

		/** Return the next element to enumerate.<br>
		 * Throw a NoSuchElementException if there is no next element. */
		public @Override E next() {
			if (!hasNext()) throw new NoSuchElementException();
			n= n - 1;
			return b[n + 1];
		}
	}
}
