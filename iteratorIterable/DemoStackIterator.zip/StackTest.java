import static org.junit.Assert.*;

import java.util.Iterator;

import org.junit.Test;

public class StackTest {

    @Test
    public void test() {
        Stack<String> st= new Stack<String>(50);
        String res= "";
        for (String s: st) {
            res= res + s + " ";
        }
        assertEquals("", res);
        
        st.push("b");
        st.push("c");
        st.push("c");
        st.push("d");
        res= "";
        for (String s: st) {
            res= res + s + " ";
        }
        assertEquals("d c c b ", res);
    }

}
