/** An instance maintains a bag of ints as a min-heap in an array of size 1500. */
public class ArrayHeap {
	private int size; // number of elements in the heap

	/** b[0..size-1] is a min-heap, i.e.<br>
	 * 1. Each array element in b[0..size-1] contains a value of the heap. <br>
	 * 2. The children of each b[k] are b[2k+1] and b[2k+2]. <br>
	 * 3. The parent of each b[k] is b[(k-1)/2].<br>
	 * 4. For each k, (parent of b[k]) <= b[k]. */
	private int[] b= new int[1500];

	/** Constructor: an empty heap. */
	public ArrayHeap() {}

	/** Return a string that gives this bag in the format: [item0, item1, ..., item(size-1)]. <br>
	 * That is, the list is delimited by '[' and ']' and ", " separates adjacent items. */
	public @Override String toString() {
		String s= "[";
		for (int k= 0; k < size; k= k + 1) {
			if (s.length() > 1) s= s + ", ";
			s= s + b[k];
		}
		return s + "]";
	}

	/** Return the number of elements in the heap. <br>
	 * This operation takes constant time. */
	public int size() {
		return size;
	}

	/** Add e to the heap. The time is O(log size-of-heap). <br>
	 * Precondition: the size of the heap is < 1500. */
	public void add(int e) {
		b[size]= e;
		size= size + 1;
		bubbleUp(size - 1);
	}

	/** Return the smallest value in the heap, without changing the heap. <br>
	 * This operation takes constant time. <br>
	 * Precondition: the heap is not empty. */
	public int peek() {
		assert 0 < size;
		return b[0];
	}

	/** Remove and return the smallest value in the heap. <br>
	 * The worst-case time is O(log size-of-heap). <br>
	 * Precondition: the heap is not empty. */
	public int poll() {
		assert 0 < size;

		if (size == 1) {
			size= 0;
			return b[0];
		}

		// At least 2 elements in heap
		int val= b[0];
		size= size - 1;
		b[0]= b[size];

		bubbleDown(0);
		return val;
	}

	/** Bubble b[k] up in heap to its right place. <br>
	 * Precondition: Every b[i] >= its parent except perhaps for b[k] */
	private void bubbleUp(int k) {
		// Inv: Every b[i] >= its parent except perhaps b[k]
		while (k > 0) {
			int p= (k - 1) / 2;  // p is k's parent
			if (b[k] >= b[p]) return;

			// Swap b[k] and b[p]
			int bp= b[p];
			b[p]= b[k];
			b[k]= bp;

			k= p;
		}
	}

	/** Bubble b[k] down in heap until it finds the right place. <br>
	 * Precondition: Every b[i] <= its children except perhaps for b[k]. */
	private void bubbleDown(int k) {
		// Invariant: Every b[i] <= its children except perhaps for b[k]
		while (2 * k + 1 < size) {   // while k has a child
			// Set c to the smaller child of k
			int c= 2 * k + 1;
			if (c + 1 < size && b[c + 1] < b[c]) c= c + 1;

			if (b[k] <= b[c]) return;

			// Swap b[k] and b[c]
			int bc= b[c];
			b[c]= b[k];
			b[k]= bc;

			k= c;
		}
	}
}