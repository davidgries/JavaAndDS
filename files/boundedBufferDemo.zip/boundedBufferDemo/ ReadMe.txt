Study class DropBox, which is a traditional bounded buffer of
one value (an integer) but with the additional requirement that
a consumer must ask either for an even integer (rye bread) or
an odd integer (white bread).

Class ProducerConsumerExample contain method main. It creates three threads:
one producer and two consumers. One consumer wnats even integers and the other
wants odd integers. Run this program as is and watch the output that is produced
--it is a running commentary on what is happening, and it never ends. Stop it when
you have seen enough.

Now change one of the notifyAll() calls in class DropBox to notify() and run again.
After some time, nothing happens. Deadlock has occurred. Run it several times. Always
deadlock, but perhaps at a different time.