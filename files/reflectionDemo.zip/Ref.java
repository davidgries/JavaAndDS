import java.lang.reflect.*;
import java.util.Arrays;
import java.util.ArrayList;
/** Demo reflection. This class contains several static methods to demo
  * the use of reflection, mainly dealing with fields of an object.*/
public class Ref {
    /* When studying the two getFields functions and getAllFields, executing
     * method main and studying its output will help you see what calls
     * on each function produces.  */
    public static void main(String[] args) throws IllegalAccessException {
        Point3 q= new Point3(3, 4, 5);
        System.out.println(getFields(q));
        System.out.println();
        
        q= new Point3(3, 4, 5);
        System.out.println(getFields(Point3.class, q));
        System.out.println();
        
        q= new Point3(7, 8, 9);
        System.out.println(getFields(Point.class, q));
        System.out.println();
        
        q= new Point3(3, 2, 1);
        System.out.println(getAllFields(q));

    }
    
    /** Print a description of the fields of ob. */
    public static void printFields(Object ob) {
        Class cb= ob.getClass();
        Field[] fields= cb.getDeclaredFields();
        System.out.println(Arrays.toString(fields));
    }
    
    /** print  "class " followed by the class name. */
    public static void printInfo(Class c) {
        System.out.println(c);
    }
    
    /** print the name of c. */
    public static void printName(Class c) {
        System.out.println(c.getName());
    }
    
    /** print the name of the class of c.
      * This prints the name of the lowest partition of c. */
    public static void printName(Object c) {
        System.out.println(c.getClass().getName());
    }
    
    /** Return a String that contains "field:value" pairs for all fields declared
      * in the lowest partition of ob, preceded by the lowest-partition name.*/
    public static String getFields(Object ob) throws IllegalAccessException {
        return getFields(ob.getClass(), ob);
    }
    
    /** Return a String that contains "field:value" pairs for all fields
      * declared in partition c of ob, preceding them with the partition name.
      * Precondition: c is indeed a partition of ob. */
    public static String getFields(Class c, Object ob) throws IllegalAccessException {
        Field[] fields= c.getDeclaredFields();
        ArrayList<String> al= new ArrayList<>();
        //invariant: al contains a value of the form "field-name:value"
        //           for each element of f that has been processed.
        for (Field f : fields) {
            f.setAccessible(true);
            al.add(f.getName() + ":" + f.get(ob));
        }
        return c.getName() + ": " + al.toString();
    }
    
    /** Return a String that contains "field:value" pairs for all partitions
      * of ob except the partition for Object (which has no fields). These
      * are given by partition, starting with the topmost partition and
      * going down to the lowest partition.
      * Precondition: ob is not null. */
    public static String getAllFields(Object ob) throws IllegalAccessException {
        Class cp= ob.getClass();
        String res= "";
        // invariant: res contains the field-values for all partitions
        //            of ob below cp, with a line break between them
        while (cp != Object.class) {
            if (res.length() != 0) res= "\n" + res;
            res= getFields(cp, ob) + res;
            cp= cp.getSuperclass();
        }
        return res;
    }
    
    /** Set the value of field x of p to v. */
    public static void setX(Point p, int v) throws NoSuchFieldException, IllegalAccessException {
        Class cp= p.getClass();
        Field f= cp.getDeclaredField("x");
        f.setAccessible(true);
        f.set(p, v);
    }
}

