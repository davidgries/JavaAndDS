import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Random;

import org.junit.Test;

public class NonComparisonTester {

	@Test
	public void testCountingSortInt() {
		int[] b= {};
		NonComparisons.countingSort(b, i -> i, 10);
		assertEquals("[]", IntArrays.toString(b));

		b= new int[] { 1 };
		NonComparisons.countingSort(b, i -> i, 4);
		assertEquals("[1]", IntArrays.toString(b));

		b= new int[] { 6, 3, 5, 7, 5, 0, 7 };
		NonComparisons.countingSort(b, i -> i, 8);
		assertEquals("[0, 3, 5, 5, 6, 7, 7]", IntArrays.toString(b));

	}

	@Test
	public void testLSDRadix() {
		int[] b= new int[] { 1 };
		NonComparisons.LSDradix(b);
		assertEquals("[1]", IntArrays.toString(b));

		b= new int[] { 6, 3, 5, 7, 5, 0, 7 };
		NonComparisons.LSDradix(b);
		assertEquals("[0, 3, 5, 5, 6, 7, 7]", IntArrays.toString(b));

		b= new int[] { 6, 53, 50, 7, 5, 0, 7 };
		NonComparisons.LSDradix(b);
		assertEquals("[0, 5, 6, 7, 7, 50, 53]", IntArrays.toString(b));

		b= new int[] { 6000, 53, 50, 7, 5, 0, 7 };
		NonComparisons.LSDradix(b);
		assertEquals("[0, 5, 7, 7, 50, 53, 6000]", IntArrays.toString(b));

		b= new int[] { 99, 5, 0 };
		NonComparisons.LSDradix(b);
		assertEquals("[0, 5, 99]", IntArrays.toString(b));

		b= new int[] { 100, 5, 0 };
		NonComparisons.LSDradix(b);
		assertEquals("[0, 5, 100]", IntArrays.toString(b));

		b= new int[] { 101, 5, 0 };
		NonComparisons.LSDradix(b);
		assertEquals("[0, 5, 101]", IntArrays.toString(b));

		b= new int[] { 4000, 3999, 2888, 184, 294, 31, 31, 32, 9, 8, 6 };
		NonComparisons.LSDradix(b);
		assertEquals("[6, 8, 9, 31, 31, 32, 184, 294, 2888, 3999, 4000]", IntArrays.toString(b));

		b= new int[1000];
		int[] c= new int[1000];
		Random r= new Random();
		for (int k= 0; k < b.length; k= k + 1) {
			b[k]= r.nextInt(100000);
			c[k]= b[k];
		}
		IntArrays.quickSort(b, 0, b.length - 1);
		NonComparisons.LSDradix(c);
		assertEquals(true, equals(b, c));
	}

	@Test
	public void testLSDRadix1() {
		int[] b= new int[] { 1 };
		NonComparisons.LSDradix(b, 2);
		assertEquals("[1]", IntArrays.toString(b));

		b= new int[] { 6, 3, 5, 7, 5, 0, 7 };
		NonComparisons.LSDradix(b, 2);
		assertEquals("[0, 3, 5, 5, 6, 7, 7]", IntArrays.toString(b));

		b= new int[] { 6, 53, 50, 7, 5, 0, 7 };
		NonComparisons.LSDradix(b, 2);
		assertEquals("[0, 5, 6, 7, 7, 50, 53]", IntArrays.toString(b));

		b= new int[] { 6000, 53, 50, 7, 5, 0, 7 };
		NonComparisons.LSDradix(b, 2);
		assertEquals("[0, 5, 7, 7, 50, 53, 6000]", IntArrays.toString(b));

		b= new int[] { 99, 5, 0 };
		NonComparisons.LSDradix(b, 2);
		assertEquals("[0, 5, 99]", IntArrays.toString(b));

		b= new int[] { 100, 5, 0 };
		NonComparisons.LSDradix(b, 2);
		assertEquals("[0, 5, 100]", IntArrays.toString(b));

		b= new int[] { 101, 5, 0 };
		NonComparisons.LSDradix(b, 2);
		assertEquals("[0, 5, 101]", IntArrays.toString(b));

		b= new int[] { 4000, 3999, 2888, 184, 294, 31, 31, 32, 9, 8, 6 };
		NonComparisons.LSDradix(b, 2);
		assertEquals("[6, 8, 9, 31, 31, 32, 184, 294, 2888, 3999, 4000]", IntArrays.toString(b));

		b= new int[1000];
		int[] c= new int[1000];
		Random r= new Random();
		for (int k= 0; k < b.length; k= k + 1) {
			b[k]= r.nextInt(100000);
			c[k]= b[k];
		}
		IntArrays.quickSort(b, 0, b.length - 1);
		NonComparisons.LSDradix(c, 2);
		assertEquals(true, equals(b, c));
	}

	@Test
	public void testLocalDate() {
		Random r= new Random(1);
		LocalDate[] ld1= new LocalDate[50];
		for (int k= 0; k < ld1.length; k= k + 1) {
			// Store in ld[k] a random day of a random year in 2000.2020
			int year= 2000 + r.nextInt(21);
			int month= 1 + r.nextInt(12);
			ld1[k]= LocalDate.of(year, month, 1);
			int maxDay= ld1[k].lengthOfMonth();
			ld1[k]= LocalDate.of(year, month, 1 + r.nextInt(maxDay));
		}
		LocalDate[] ld2= Arrays.copyOf(ld1, ld1.length);
		NonComparisons.sort(ld1);
		ComparableArrays.quickSort(ld2, 0, ld2.length - 1);
		assertEquals(true, equals(ld1, ld2));
	}

	@Test
	public void testCountingSortObj() {
		Integer[] b= {};
		NonComparisons.countingSort(b, i -> i, 10);
		assertEquals("[]", IntArrays.toString(b));

		b= new Integer[] { 1 };
		NonComparisons.countingSort(b, i -> i, 4);
		assertEquals("[1]", IntArrays.toString(b));

		b= new Integer[] { 6, 3, 5, 7, 5, 0, 7 };
		NonComparisons.countingSort(b, i -> i, 8);
		assertEquals("[0, 3, 5, 5, 6, 7, 7]", IntArrays.toString(b));
	}

	@Test
	public void testPigeonholeSort() {
		Integer[] b= new Integer[] { 1 };
		NonComparisons.pigeonholeSort(b, i -> i, 1, 1);
		assertEquals("[1]", IntArrays.toString(b));

		b= new Integer[] { 6, 3, 5, 7, 5, 0, 7 };
		NonComparisons.pigeonholeSort(b, i -> i, 0, 8);
		assertEquals("[0, 3, 5, 5, 6, 7, 7]", IntArrays.toString(b));

		b= new Integer[1000];
		Integer[] c= new Integer[1000];
		Random r= new Random();
		for (int k= 0; k < b.length; k= k + 1) {
			Integer d= r.nextInt(100);
			b[k]= d;
			c[k]= d;
		}
		ComparableArrays.quickSort(b, 0, b.length - 1);
		NonComparisons.pigeonholeSort(c, key -> key);
		assertEquals(true, equals(b, c));
	}

	@Test
	public void testPigeonholeIntSort() {
		int[] b= new int[] { 1 };
		NonComparisons.pigeonholeSort(b);
		assertEquals("[1]", IntArrays.toString(b));

		b= new int[] { 6, 3, 5, 7, 5, 0, 7 };
		NonComparisons.pigeonholeSort(b);
		assertEquals("[0, 3, 5, 5, 6, 7, 7]", IntArrays.toString(b));

		b= new int[1000];
		int[] c= new int[1000];
		Random r= new Random();
		for (int k= 0; k < b.length; k= k + 1) {
			int d= r.nextInt(100);
			b[k]= d;
			c[k]= d;
		}
		IntArrays.quickSort(b, 0, b.length - 1);
		NonComparisons.pigeonholeSort(c);
		assertEquals(true, equals(b, c));
	}

	/** return b = c. */
	public static boolean equals(int[] b, int[] c) {
		if (b.length != c.length) return false;
		for (int k= 0; k < b.length; k= k + 1) {
			if (b[k] != c[k]) return false;
		}
		return true;
	}

	/** return b = c. */
	public static <T> boolean equals(T[] b, T[] c) {
		if (b.length != c.length) return false;
		for (int k= 0; k < b.length; k= k + 1) {
			if (!b[k].equals(c[k])) return false;
		}
		return true;
	}

}
