import java.util.Arrays;

/** Class contains static methods for sorting and search using a Comparable[].<br>
 * If the array elements are not consistent, a ClassCastException it thrown.<br>
 * For example, having one element be a String and another an Integer won't work.<br>
 * <br>
 *
 * Included, in this order, are:<br>
 *
 * linearSearch: linear search an array<br>
 *
 * binarySearch: binary search a sorted array<br>
 *
 * min: to find the minimum of b[h..k]<br>
 *
 * selectionSort: to sort an array, which calls min<br>
 *
 * selectionSort1: to sort an array, which finds min in place<br>
 *
 * insertValue: to insert a value into its sorted position in b[h..k-1]<br>
 *
 * insertionSort: to sort an array<br>
 *
 * partition0: as done in class<br>
 *
 * partition: used in quicksort, done a bit more efficiently<br>
 *
 * medianOf3: swap median of b[h], b[(h+k)/2, b[k] into b[k]<br>
 *
 * copy: return a copy of b[h..k]<br>
 *
 * merge: merge sorted b[h..e] and b[e+1..k] into b[h..k]<br>
 *
 * mergesort: to sort b[h..k] recursively<br>
 *
 * quicksort0: the basic quicksort algorithm<br>
 *
 * quicksort: quicksort0 changed to fix inefficiencies<br>
 *
 * toString: create a String that contains elements of an array<br>
 *
 * @Author David Gries */
public class ComparableArrays {

	/** = index of x in b ---or the length of b if x is not in b. */
	public static <T extends Comparable<T>> int linearSearch(T[] b, T x) {
		// invariant: x is not in b[0..i-1]
		int i;
		for (i= 0; i != b.length && b[i].compareTo(x) != 0; i= i + 1) {
		}
		return i;
	}

	/** Assume virtual elements b[-1] = -infinity and b.[b.length] = +infinity. <br>
	 * Return a value i that satisfies R: b[i] <= x < b[i+1] */
	public static <T extends Comparable<T>> int binarySearch(T[] b, T x) {
		int i= -1;
		int j= b.length;
		// inv: b[0i] <= x < b[j] and -1 <= i < j <= b.length, i.e.

		// 0--------i----------j---------- b.length
		// b | |<=x| ? |>x| |
		// -------------------------------
		while (j != i + 1) {
			int e= (i + j) / 2;
			// -1 <= i < e < j <= b.length
			if (b[e].compareTo(x) <= 0) i= e;
			else j= e;
		}
		return i;
	}

	/** = the position of the minimum value of b[h..k].<br>
	 * Precondition: h < k. */
	public static <T extends Comparable<T>> int min(T[] b, int h, int k) {
		int p= h;
		int i= h;
		// inv: b[p] is the minimum of b[h..i], i.e.
		//
		// h-------p------------i---------k
		// b | b[p] is min of this | ? |
		// --------------------------------

		while (i != k) {
			i= i + 1;
			if (b[p].compareTo(b[i]) > 0) {
				p= i;
			}
		}
		return p;
	}

	/** Sort b --put its elements in ascending order. */
	public static <T extends Comparable<T>> void selectionSort(T[] b) {
		int j= 0;
		// inv P: b[0..j-1] is sorted and b[0..j-1] <= b[j..], i.e.

		// 0---------------j--------------- b.length
		// inv : b | sorted, <= | >= |
		// --------------------------------

		while (j != b.length) {
			int p= min(b, j, b.length - 1);
			// b[p] is minimum of b[j..b.length-1]
			// Swap b[j] and b[p]
			T t= b[j];
			b[j]= b[p];
			b[p]= t;

			j= j + 1;
		}
	}

	/** Sort b --put its elements in ascending order. */
	public static <T extends Comparable<T>> void selectionSort1(T[] b) {
		int j= 0;
		// inv P: b[0..j-1] is sorted and b[0..j-1] <= b[j..], i.e.

		// 0---------------j--------------- b.length
		// inv : b | sorted, <= | >= |
		// --------------------------------

		while (j != b.length) {
			// Put into p the index of smallest element in b[j..]
			int p= j;
			for (int i= j + 1; i != b.length; i++ ) {
				if (b[i].compareTo(b[p]) < 0) p= i;
			}

			// Swap b[j] and b[p]
			T t= b[j];
			b[j]= b[p];
			b[p]= t;
			j= j + 1;
		}
	}

	/** Precondition: b[h..k-1] is sorted, and b[k] contains a value.<br>
	 * Sort b[h..k]. */
	public static <T extends Comparable<T>> void insertValue(T[] b, int h, int k) {
		T v= b[k];
		int i= k;
		/* inv P: (1) Placing v in b[i] makes b[h..k] a permutation of its initial value
		 * (2) b[h..k] with b[i] removed is initial b[h..k-1] (3) v < b[i+1..k] */
		while (i != h && b[i - 1].compareTo(v) > 0) {
			b[i]= b[i - 1];
			i= i - 1;
		}
		b[i]= v;
	}

	/** Sort b[h..k] --put its elements in ascending order. */
	public static <T extends Comparable<T>> void insertionSort(T[] b, int h, int k) {
		// inv: h <= j <= k+1 and b[h..j-1] is sorted, i.e.

		// h---------------j--------------k
		// inv : b | sorted, | ? |
		// --------------------------------

		for (int j= h; j <= k; j= j + 1) {
			// Sort b[h..j], given that b[h..j-1] is sorted
			insertValue(b, h, j);
		}
	}

	/** b[h..k] has at least three elements.<br>
	 * Let x be the value initially in b[h].<br>
	 * Permute b[h..k] and return integer j satisfying R:<br>
	 *
	 * b[h..j-1] <= b[j] = x <= b[j+1..k] */
	public static <T extends Comparable<T>> int partition0(T[] b, int h, int k) {
		//
		// h---------------------------k
		// pre: b |x| ? | for some x
		// -----------------------------
		//
		// h-------------j-------------k
		// post: b | <= x |x| >= x |
		// -----------------------------
		int j= h;
		T x= b[h];
		int i= k;
		// inv P: b[h..j-1] <= x <= b[i+1..k], i.e.
		//
		// h---------j-------i------------k
		// post: b | <= x |x| ? | >= x |
		// --------------------------------
		while (j < i) {
			if (b[j + 1].compareTo(x) <= 0) {
				b[j]= b[j + 1];
				j= j + 1;
			} else {
				T temp= b[j + 1];
				b[j + 1]= b[i];
				b[i]= temp;
				i= i - 1;
			}
		}
		b[j]= x;
		return j;
	}

	/** Permute b[h..k] and return integer j satisfying R:<br>
	 *
	 * b[h..j-1] <= b[j] = x <= b[j+1..k]<br><br>
	 *
	 * where x stands for the value initially in b[h].<br>
	 * Precondition: b[h..k] has at least three elements. */
	public static <T extends Comparable<T>> int partition(T[] b, int h, int k) {
		int j;
		// Truthify R1: b[h+1..j] <= b[h] = x <= b[j+1..k];
		int i= h + 1;
		j= k;

		// inv P: b[h+1..i-1] <= x <= b[j+1..k], i.e.
		//
		// h---------i------j----------k
		// b |x| <= x | ? | >= x |
		// -----------------------------
		while (i <= j) {
			if (b[i].compareTo(b[h]) <= 0) {
				i= i + 1;
			} else if (b[j].compareTo(b[h]) >= 0) {
				j= j - 1;
			} else {// b[j] < x < b[i]
				T t1= b[i];
				b[i]= b[j];
				b[j]= t1;
				i= i + 1;
				j= j - 1;
			}
		}
		T temp= b[h];
		b[h]= b[j];
		b[j]= temp;
		// R
		return j;
	}

	/** Permute b[h], b[(h+k)/2], and b[k] to put their median in b[h]. */
	@SuppressWarnings("unchecked")
	public static <T extends Comparable<T>> void medianOf3(T[] b, int h, int k) {
		int e= (h + k) / 2; // index of middle element of array
		int m; // index of median
		// Return if b[h] is median; else store index of median in m
		if (b[h].compareTo(b[e]) <= 0) {
			if (b[h].compareTo(b[k]) >= 0) return;
			// b[h] is smallest of the three
			if (b[k].compareTo(b[e]) <= 0) m= k;
			else m= e;
		} else {
			if (b[h].compareTo(b[k]) <= 0) return;
			// b[h] is largest of the three
			if (b[k].compareTo(b[e]) <= 0) m= e;
			else m= k;
		}
		T t= b[h];
		b[h]= b[m];
		b[m]= t;
	}

	/** Sort b[h..k] --put its elements in ascending order.<br>
	 * Precondition: Segments b[h..e] and b[e+1..k] are already sorted. */
	public static <T extends Comparable<T>> void merge(T b[], int h, int e, int k) {
		T[] c= Arrays.copyOfRange(b, h, e + 1);
		// c is a copy of original b[h..k]
		int i= h;
		int j= e + 1;
		int m= 0;
		/*
		 * inv: b[h..i-1] contains the moved values, stably sorted, b[j..k] contains the
		 * unmoved values in b[e+1..k], c[m..e-h] contains the unmoved values in c[0..],
		 * b[h..i-1] <= b[j..k] and b[h..i-1] <= c[m..].
		 */
		// Move values as long as b[j..k] and c[m..e-h] are not empty
		while (j <= k && m <= e - h) {
			if (c[m].compareTo(b[j]) <= 0) {
				b[i]= c[m];
				m++ ;
			} else {
				b[i]= b[j];
				j++ ;
			}
			i++ ;
		}

		// Move values from c[m..e-h]
		while (m <= e - h) {
			b[i]= c[m];
			i++ ;
			m++ ;
		}
	}

	/** Sort b[h..k] --put its elements in ascending order. */
	public static <T extends Comparable<T>> void mergeSort(T[] b, int h, int k) {
		if (h >= k) return;

		int e= (h + k) / 2;
		mergeSort(b, h, e); // Sort b[h..e]
		mergeSort(b, e + 1, k); // Sort b[e+1..k]
		merge(b, h, e, k); // Merge the 2 segments
	}

	/** Sort b[h..k] --put its elements in ascending order. */
	public static <T extends Comparable<T>> void quickSort0(T[] b, int h, int k) {
		if (k + 1 - h < 2) return;

		int j= partition(b, h, k);
		// b[h..j-1] <= b[j] <= b[j+1..k]
		quickSort0(b, h, j - 1);
		quickSort0(b, j + 1, k);
	}

	/** Sort b[h..k] --put its elements in ascending order. */
	public static <T extends Comparable<T>> void quickSort(T[] b, int h, int k) {
		int h1= h;
		int k1= k;

		// invariant: b[h..k] is sorted if b[h1..k1] is
		while (true) {
			if (k1 - h1 < 10) {
				insertionSort(b, h1, k1);
				return;
			}
			medianOf3(b, h1, k1);
			// b[h1] is between b[(h1+k1)/2] and b[k1]

			int j= partition(b, h1, k1);
			// b[h..j-1] <= b[j] <= b[j+1..k], i.e.
			//
			// h1---------j-------k1
			// b | <= x |x| >= x | for some x
			// ---------------------
			if (j - h1 <= k1 - j) {
				quickSort(b, h1, j - 1);
				// b[j+1..k1] remains to be sorted
				h1= j + 1;
			} else {
				quickSort(b, j + 1, k1);
				// b[h1..j-1] remains to be sorted
				k1= j - 1;
			}
		}
	}

	/** Return values of b, separated by ", " and with the whole list delimited by "[" and "]". */
	public static <T> String toString(T[] b) {
		String res= "[";
		// inv: res contains b[0..k-1], with "[" at
		// beginning and values separated by ", "
		for (int k= 0; k != b.length; k= k + 1) {
			if (k != 0) res= res + ", ";
			res= res + b[k];
		}
		return res + "]";
	}

}
