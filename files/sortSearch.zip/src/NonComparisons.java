import java.lang.reflect.Array;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.function.ToIntFunction;

/** Class contains static methods for sorting using three non-comparison sorting methods.<br>
 *
 * 1. pigeonhole sort to sort an int array of nonnegative values.
 *
 * 2.pigeonhole sort that uses a function f to determine which pigeon hole<br>
 * each value goes. This relies on a third pigeonhole sort method that has<br>
 * two extra parameters: the min and max values in the array.<br>
 *
 * 3. counting sort, to sort an int array. Int parameter b gives the number<br>
 * of buckets, and function f determines which bucket each array value is placed.<br>
 *
 * 4. counting sort, like that above but the array can be of any class type.<br>
 *
 * 5. LSDradix, a radix sort to sort an int array using radix 10. It relies on<br>
 * counting sort.<br>
 *
 * 6. LSDradix, a radix sort to sort an int array using radix b (a parameter).<br>
 * It relies on counting sort.<br>
 *
 * 7. sort(LocalDate[] c). A example to show the use of counting sort. To sort<br>
 * as array of LocalDates, it call counting sort three time: to sort on the day<br>
 * of the month, the month, and the year. */
public class NonComparisons {

	/** Sort array c. The sort is stable.<br>
	 * Precondition: c.length > 0. The c[i] satisfy 0 <= c[i].<br>
	 * The time complexity is O(n*v) where n is the size of c and <br>
	 * v is the maximum value in c. */
	public static void pigeonholeSort(int[] c) {
		// Create s empty pigeon holes in phole[0..size-1].
		int s= max(c) + 1;  // number of pigeon holes
		ArrayList<Integer>[] phole= new ArrayList[s];
		for (int k= 0; k < s; k= k + 1) phole[k]= new ArrayList<>();

		// Append each c[i] to pigeon hole phole[c[i]]).
		for (int t : c) phole[t].add(t);

		// Move the values from the pigeon holes back to c.
		int k= 0;
		for (ArrayList<Integer> ph : phole) {
			// move elements of pigeon hole ph to c.
			for (int ob : ph) {
				c[k]= ob;
				k= k + 1;
			}
		}
	}

	/** Sort array c according to function f. The sort is stable.<br>
	 * Precondition: c.length > 0.<br>
	 * Precondition: For each key c[i], f(key) yields an integer.<br>
	 * The keys are sorted based on f(key): <br>
	 * c[h] comes before c[k] if f(c[h]) < f(c[k]).<br>
	 * <br>
	 * The time complexity is O(n*v) where n is the size of c and <br>
	 * v = (max value in c) - (min value in c). <br>
	 * This assumes that a call on function f takes constant time. */
	public static <T> void pigeonholeSort(T[] c, ToIntFunction<T> f) {
		// Let the f(c[i]) range from min to min + size-1.
		int min= min(c, f);
		int max= max(c, f);
		pigeonholeSort(c, f, min, max);
	}

	/** Sort array c according to function f. The sort is stable.<br>
	 * Precondition: c.length > 0.<br>
	 * Precondition: For each key c[i], f(key) yields an integer.<br>
	 * The keys are sorted based on f(key): <br>
	 * c[h] comes before c[k] if f(c[h]) < f(c[k]).<br>
	 * Precondition: Each key c[i] satisfies min <= f(key) <= max. <br>
	 * <br>
	 * The time complexity is O(n*v) where n is the size of c and <br>
	 * v = max - min. <br>
	 * This assumes that a call on function f takes constant time. */
	public static <T> void pigeonholeSort(T[] c, ToIntFunction<T> f, int min, int max) {
		// Let the f(c[i]) range from min to min + size-1.
		// Create size empty pigeon holes in phole[0..size-1].
		int size= max + 1 - min;
		ArrayList[] phole= (ArrayList[]) Array.newInstance(ArrayList.class, size);
		for (int k= 0; k < size; k= k + 1) phole[k]= new ArrayList<>();

		// Append each c[i] to phole[f(c[i] - min).
		for (T t : c) phole[f.applyAsInt(t) - min].add(t);

		// Move the values from the pigeon holes back to c.
		int k= 0;
		for (ArrayList<Object> q : phole) {
			// move elements of q to c
			for (Object ob : q) {
				c[k]= (T) ob;
				k= k + 1;
			}
		}
	}

	/** Sort c according to function f. The sort is stable.<br>
	 *
	 * Precondition: f(key) returns an integer in the range 0..b-1, i.e.<br>
	 *
	 * The values c[i] are the keys. They satisfy 0 <= f(key) < b. .<br>
	 *
	 * Upon termination, c contains items with f(key) = 0, then 1, and so on, i.e.<br>
	 * Postcondition:<br>
	 * ----------------------------------------------------------------------------<br>
	 * c | keys with f(key) = 0 | keys with f(key) = 1 | ... | keys with f(key) = b-1 |<br>
	 * ----------------------------------------------------------------------------<br>
	 *
	 * Using n for c.length, we give space and time complexity:<br>
	 * Space used: O(n + b). Worst-case and expected time: O(n + b). */
	public static void countingSort(int[] c, ToIntFunction<Integer> f, int b) {
		// Store in each d[i] the number of times i occurs in c.
		int[] d= new int[b];
		for (int t : c) d[f.applyAsInt(t)]+= 1;

		// Change each d[i] to the sum of d[0..i-1].
		// Using the notation dInt[i] for the initial value of d[i], we have:
		// invariant: 0 <= h < b and
		// total= sum of dInit[0..h-1] and
		// For all i, 0 <= i < h, d[i] = sum of dInit[0..i-1] and
		// For all i, h <= i < c.length, d[i] = dInit[i].
		int total= 0;
		for (int h= 0; h < d.length; h= h + 1) {
			int t= d[h];
			d[h]= total;
			total= total + t;
		}

		// Store keys in sorted, stable order in res
		int[] res= new int[c.length];
		// invariant: keys c[0..h-1] have been placed in their correct position in res.
		// For each t, 0 <= t < b, the next value v in c[h..] with f(v) = t
		// (if there is one) belongs in res[d[t]].
		for (int h= 0; h < c.length; h= h + 1) {
			int t= f.applyAsInt(c[h]);
			res[d[t]]= c[h];
			d[t]= d[t] + 1;
		}

		// copy res to c
		for (int k= 0; k < c.length; k= k + 1) c[k]= res[k];
	}

	/** Sort c according to function f. The sort is stable.<br>
	 * Precondition: c.length is not 0.<br>
	 * Precondition: f(key) returns an integer in the range 0..b-1, i.e.:<br>
	 * The c[i] are the keys. They satisfy 0 <= f(key) < b.<br>
	 *
	 * Upon termination, c contains items with f(key) = 0, then 1, and so on.<br>
	 *
	 * Postcondition:<br>
	 * ---------------------------------------------------------------------------- <br>
	 * c | keys with f(key) = 0 | keys with f(key) = 1 | ... | keys with f(key) = b-1 |<br>
	 * ----------------------------------------------------------------------------<br>
	 *
	 * Using n for c.length, we give space and time complexity:<br>
	 * Space used: O(n + b). Worst-case and expected time: O(n + b). */
	public static <T> void countingSort(T[] c, ToIntFunction<T> f, int b) {
		// Store in each d[i] the number of times i occurs in c.
		int[] d= new int[b];
		for (T t : c) d[f.applyAsInt(t)]+= 1;

		// Change each d[i] to the sum of d[0..i-1].
		// Using the notation dInt[i] for the initial value of d[i], we have:
		// invariant: 0 <= h < b and
		// total= sum of dInit[0..h-1] and
		// For all i, 0 <= i < h, d[i] = sum of dInit[0..i-1] and
		// For all i, h <= i < c.length, d[i] = dInit[i].
		int total= 0;
		for (int h= 0; h < d.length; h= h + 1) {
			int t= d[h];
			d[h]= total;
			total= total + t;
		}

		// Store keys in sorted, stable order in res
		T[] res= (T[]) Array.newInstance(Object.class, c.length);
		// invariant: keys c[0..h-1] have been moved to their correct position.
		// For each t, 0 <= t < b, the next value v in c[h..] with f(v) = t
		// (if there is one) belongs in res[d[t]].
		for (int h= 0; h < c.length; h= h + 1) {
			int t= f.applyAsInt(c[h]);
			res[d[t]]= c[h];
			d[t]= d[t] + 1;
		}

		// Copy res to c
		for (int k= 0; k < c.length; k= k + 1) c[k]= res[k];
	}

	/** Sort c, using radix sort with radix 10.<br>
	 * Precondition: elements of c are non-negative.<br>
	 * We give the complexity using n for the size of c and max for the largest value in c:<br>
	 * Space used: O(n). Worst-case and expected time: O(n log max). */
	public static void LSDradix(int[] c) {
		int max= max(c); // maximum value in c.
		int k= 0;
		int e= 1;
		// invariant: c contains initial c sorted on its k least significant digits AND
		// e = 10^k
		while (e <= max) {
			int e1= e;
			// if k = 0, f(v) = least significant digit of v
			// if k = 1, f(v) = second least significant digit of v
			// ...
			countingSort(c, key -> key / e1 % 10, 10);
			e= 10 * e;
			k= k + 1;
		}
	}

	/** Sort c, using radix sort with radix b.<br>
	 * Precondition: elements of c are non-negative.<br>
	 * We give the complexity using n for the size of c and max for the largest value in c:<br>
	 * Space used: O(n). Worst-case and expected time: O(n log[b] max). */
	public static void LSDradix(int[] c, int b) {
		int max= max(c); // maximum value in c.
		int k= 0;
		int e= 1;
		// invariant: c contains initial c sorted on its k least significant digits AND
		// e = radix^k
		while (e <= max) {
			int e1= e;
			// if k = 0, f(v) = least significant digit of v
			// if k = 1, f(v) = second least significant digit of v
			// ...
			countingSort(c, key -> key / e1 % b, b);
			e= b * e;
			k= k + 1;
		}
	}

	/** Return the max value in c. <br>
	 * Precondition: c.length > 0. */
	public static int max(int[] c) {
		int max= c[0];
		for (int i= 1; i < c.length; i= i + 1) if (c[i] > max) max= c[i];
		return max;
	}

	/** Return the min value in c. <br>
	 * Precondition: c.length > 0. */
	public static int min(int[] c) {
		int min= c[0];
		for (int i= 1; i < c.length; i= i + 1) if (c[i] < min) min= c[i];
		return min;
	}

	/** Return the minimum of the values f(c[i]). <br>
	 * Precondition: c.length > 0. */
	public static <T> int min(T[] c, ToIntFunction<T> f) {
		T min= c[0];
		int fOfMin= f.applyAsInt(c[0]);
		for (int i= 1; i < c.length; i= i + 1) if (f.applyAsInt(c[i]) < fOfMin) {
			min= c[i];
			fOfMin= f.applyAsInt(c[i]);
		}
		return fOfMin;
	}

	/** Return the maximum of the values f(c[i]). <br>
	 * Precondition: c.length > 0. */
	public static <T> int max(T[] c, ToIntFunction<T> f) {
		T max= c[0];
		int fOfMax= f.applyAsInt(c[0]);
		for (int i= 1; i < c.length; i= i + 1) if (f.applyAsInt(c[i]) > fOfMax) {
			max= c[i];
			fOfMax= f.applyAsInt(c[i]);
		}
		return fOfMax;
	}

	/** Sort c. <br>
	 * Precondition: The years of elements of c are in 2000..2020 */
	public static void sort(LocalDate[] c) {
		ToIntFunction<LocalDate> f= key -> key.getDayOfMonth();
		countingSort(c, key -> key.getDayOfMonth(), 32);
		countingSort(c, key -> key.getMonthValue(), 13);
		countingSort(c, key -> key.getYear() - 2000, 21);
	}

	/** Return values of b, separated by ", " and with whole list delimited by "[" and "]". */
	public static String toString(Object[] b) {
		String res= "[";
		// inv: res contains b[0..k-1], with "[" at
		// beginning and values separated by ", "
		for (int k= 0; k != b.length; k= k + 1) {
			if (k != 0) res= res + ", ";
			res= res + b[k];
		}
		return res + "]";
	}

	/** Return values of b, separated by ", " and with whole list delimited by "[" and "]". */
	public static String toString(int[] b) {
		String res= "[";
		// inv: res contains b[0..k-1], with "[" at
		// beginning and values separated by ", "
		for (int k= 0; k != b.length; k= k + 1) {
			if (k != 0) res= res + ", ";
			res= res + b[k];
		}
		return res + "]";
	}
}
