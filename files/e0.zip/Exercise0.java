/** This class contains simple methods for students to write to get learn<br>
 * Java syntax. Class Exercise0Test contains all the test cases need to<br>
 * check that the methods were written correctly.
 *
 * With each method, we tell you where to look in JavaHyperText to read<br>
 * about each Java feature and its syntax. Instead of just trying things<br>
 * until they work, read the JavaHyperText material and use it to help<br>
 * you write the code.
 *
 * Each method body has in it a throw statement. When the method it called, its <br>
 * execution will stop with the exception being thrown. This is simply a way of <br>
 * letting the user know that the method has not been written yet. <br>
 * Replace the throw statement by the code you write for it.
 *
 * @author david gries */
public class Exercise0 {

	/** Return the sum of the values 6, 7, 8, 9 */
	public static int sum1() {
		/*TODO: This requires only one line of code: a return statement.
		 * Method sum1 is a FUNCTION, since its return type is "int".
		 *
		 * Look at entry   return   in JavaHyperText and read about a return
		 * statement in a function. We will use the return statement in a
		 * procedure later. */
		throw new UnsupportedOperationException();
	}

	/** If x = 0, return 0; <br>
	 * Otherwise, return the sum of the values 6, 7, 8, 9 */
	public static int sum2(int x) {
		/* TODO: This and the next 4-5 methods require an if-statement or an
		 * if-else statement. Open the pdf file at JavaHyperText entry
		 *    if-statement    and keep it open for reference for these methods.
		 * In the pdf file, look at the first, leftmost example. Use
		 * that form, but instead of "x= y;" use a return statement.
		 * Thus:
		 *
		 * 1. Implement the first statement in the specification: Write an
		 * if-statement whose then-part returns 0.
		 *
		 * 2. Implement the second line of the spec. Just write
		 * a return statement. That's it.
		 *
		 * Read the syntax/semantics of the if-statement at the bottom of the page.
		 */
		throw new UnsupportedOperationException();
	}

	/** If x = 0, set x to y and y to 2.<br>
	 * Then return the value of x + y. */
	public static int sum3(int x, int y) {
		/* TODO: Read JavaHyperText entry   block   .
		 *
		 * If the then-part of an if-statement requires several statements,
		 * we write that then-part as a block with those statements inside it.
		 *
		 * 1. Translate the first sentence of the spec into Java;
		 *
		 * 3. translate the second sentence of the spec into into Java. */
		throw new UnsupportedOperationException();
	}

	/** If x <= y, set x to y and y to 2; otherwise, set y to x.<br>
	 * Then return the value of 2x + y. */
	public static int sum4(int x, int y) {
		/* TODO: Read about the if-else statement in JavaHyperText. In particular,
		 * read about its syntax/semantics at the bottom of the page of the pdf file.
		 *
		 * In this method, an if-else statement is needed.
		 * To write this method, first translate the first sentence into
		 * an if-else statement; then translate the second sentence into
		 * a return statement. */
		throw new UnsupportedOperationException();
	}

	/** If x < y, return y; otherwise return 2x. */
	public static int conditional(int x, int y) {
		/* TODO: This exercise concerns the "conditional expression", a very
		 * useful tool. Type   ?  into the JavaHyperText Filter Field and read
		 * about it.
		 *
		 * Write this method body as a single, one-line, return statement
		 * whose expression is a conditional expression. */
		throw new UnsupportedOperationException();
	}

	/** If x = 0, print 1; <br>
	 * Otherwise, print 2x */
	public static void p(int x) {
		/* TODO: This exercise introduces you to the return statement in a
		 * procedure --a method with  void   as the return type. Type
		 *    return   into the JavaHyperText Filter Field and read about it.
		 *
		 *1. The goal here is to get you to see that execution of the return
		 * statement terminates execution of the method body; nothing else
		 * happens in this method after that.
		 *
		 * 2. Within the JUnit testing class, the only way to know that this
		 * this method does the right thing is to look at what it prints in the
		 * Console. That's not so good but we live with it. Look at how we
		 * do that in method testP, annotating what is printed to help the reader.
		 * Don't use this way of testing, by looking at printed output,
		 * unless there is no other choice.
		 *
		 * 3. To print the value of an expression like b + c, write:
		 *      System.out.println(b+c);
		 *
		 * 4. Write this method with two statements:
		 *    (1) An if-statement that performs the first line of the spec
		 *        and returns, using a return statement.
		 *    (2) A print statement that performs the second line of the spec.
		 */
		throw new UnsupportedOperationException();
	}

	/** If b < c, then swap b and c.<br>
	 * Then return the value of 2b * c. */
	public static long local1(long b, long c) {
		/* TODO: This exercise introduces you to local variables.
		 * Open the pdf file in JavaHyperText entry   local variable   and
		 * study the first part, about declarations of local variables. Study the
		 * short method that appears to the right there. After writing this method,
		 * you may want to peruse the rest of the pdf file.
		 *
		 * Complete this method body by:
		 * (1) Translating the first sentence of the spec into Java;
		 * (2) Translating the second sentence of the spec in =to Java.
		*/
		throw new UnsupportedOperationException();
	}

	/** If b < c, then swap b and c.<br>
	 * Then return the value of 2b * c. */
	public static long local2(long b, long c) {
		/* TODO: The pdf file on local variables says that, since Java 10, one can
		 * use "var" instead of a type in a declaration of a local variable as
		 * long as the type can be inferred from the context.
		 *
		 * Write this method as you did the previous one, but declare the local
		 * variable using "var" instead of a type. */
		throw new UnsupportedOperationException();
	}

	/** Return 0. */
	public static double local3(double b, double c) {
		/* TODO: The pdf file on local variables tells you that local
		 * variables are uninitialized. To gain experience with this fact,
		 * replace the value  0  in the return statement by  m  . What
		 * happens? Once you understand, change the   m  back to 0 so the
		 * method compiles. */
		int m;
		return 0;
	}

	/** Return the sum of values in n..m. <br>
	 * Note: we use n..m to denote the values n, n+1, n+2, ..., m. */
	public static double loop1(int n, int m) {
		/* TODO: In JavaHyperText, open the pdf file at entry   for-loop   and
		 * study the material down to point 6 about for-loops.
		 *
		 * Write a loop in this method body so that the specification
		 * is implemented. The first statement should declare a local
		 * variable, say s, to contain the sum. */
		throw new UnsupportedOperationException();
	}

	/** Return the sum of the even values in n..m. */
	public static int loop2(int n, int m) {
		/* TODO: Sometimes, it is easier to declare and initialize the
		 * loop counter before the loop. Then, the loop initialization
		 * can be empty. (See pt 3 of the for-loop pdf file) That's the case here.
		 * Set it to either n or n+1 depending on which is even. .
		 *
		 * Write this method declaring the loop counter before the loop,
		 * setting the loop counter to n or n+1, depending on which is even.
		 * Also, the increment of the for-loop should increase the loop
		 * counter by 2.
		 * Use n%2 == 0 to test whether n is even.
		 */
		throw new UnsupportedOperationException();
	}

	/** Return the last value of n..m that is divisible by 5 <br>
	 * return n-1 if none. */
	public static int loop3(int n, int m) {
		/* TODO: Your loop you should decrease the control
		 * variable by 1 after each iteration.
		 * Use k%5 == 0 to test whether k is divisible by 5.
		 * The repetend should execute a return statement when the answer
		 * is found.
		 *
		 * Do NOT declare any local variables except the loop counter.
		 * Do NOT use a break statement within the repetend. */
		throw new UnsupportedOperationException();
	}

	/** Return the sum of the even values in n..m. */
	public static int loop4(int n, int m) {
		/* TODO: The next set of methods deal with the while-loop.
		 * Open the pdf file in entry    while-loop   in JavaHyperText and
		 * read about the while loop. Don't look at point 4; we'll cover
		 * that later in the course.
		 *
		 * This method does the same thing as method loop2. But
		 * write it using a while-loop.
		 */
		throw new UnsupportedOperationException();
	}

	/** Any positive integer n can be written in this form: c*2^y, where <br>
	 * both c and y are positive and c is odd. <br>
	 * Return the value c. <br>
	 * Precondition: n > 0 */
	public static int loop5(int n) {
		/* TODO: Write a while-loop that continually divides n by 2
		 * until n is odd. Then return n.
		 *
		 * Use   n%2 == 0   to test whether n is even.*/
		throw new UnsupportedOperationException();
	}

}
