
import java.util.Arrays;
import java.util.Random;

/** This class contains an algorithm for in-place merge sort developed by Mostafa <br>
 * Jafarzadeh of Iran <m.b_jafarzadeh@yahoo.com> and massaged to simplify its <br>
 * presentation and provide a proof (through the use of assertions and invariants <br>
 * written as array diagrams) by David Gries <gries@cs.cornell.edu>.
 *
 * It turns out that Mostafa's merge algorithm does have worst-case time O(n^d)<br>
 * where d is about 1.5072 to sort an array of size n. Thus, it is not the hoped-for <br>
 * linear-time in-place merge. Nevertheless, it provides an interesting approach<br>
 * and a great example of the use of array diagrams for assertions and loop invariants<br>
 * to provide understanding.
 *
 * It is best to understand Mostafa's merge algorithm by looking first at method <br>
 * mostafaMergeSimple. This is his basic innovative merge algorithm. Understand that <br>
 * algorithm in terms of all the assertions and the loop invariant there and you get <br>
 * the idea. But various modifications are needed to make it most efficient. Two <br>
 * ways are introduced for to improve efficiency.
 *
 * Mostafa's algorithm is recursive, with two recursive calls. Fortunately, the second <br>
 * recursive call is tail-recursive, so it can be implemented without requiring an extra <br>
 * frame on the call stack. However, Java does not (yet) optimize tail recursion. Therefore, <br>
 * we use the technique given in the online free textbook JavaHyperText<br>
 * (see https://www.cs.cornell.edu/courses/JavaAndDS/files/recursionTail.pdf) to change<br>
 * that tail-recursive call into iteration (a loop). Thus, the maximum depth of<br>
 * recursion of mostafaMerge is log n to merge two segments whose total size is n.<br>
 * Therefore, merge sort using mostafaMerge requires space O(log n) to sort an<br>
 * array of size n.
 *
 * Do study the 2-page pdf file mentioned above to see how easy it is to implement<br>
 * tail-recursion efficiently. Then look at Method mostafaMerge to see this implementation <br>
 * in action.
 *
 * To make Mostafa's merge algorithm more efficient, method mostafaMerge is given a <br>
 * new parameter, isAsc, to indicate whether the second section is in ascending or <br>
 * descending order. Also lot of case analysis is introduced to reduce the amount of <br>
 * unnecessary work that might be done. Generally, we eschew unnecessary case analysis, <br>
 * and we wish we did not need so much here.
 *
 * * Method main creates a large array of random values, and sorts the array using <br>
 * Quicksort (in the Java library), TimSort (in the Java library), a typical mergeSort <br>
 * (written by Gries), and mostafaSort (the new algorithm). For each, it prints the <br>
 * elapsed time to sort.
 *
 *
 * @authors Mostafa Jafarzadeh and David Gries */
public class MostafaMerge {

	public static void main(String[] pars) {
		int seed= 18;            // Seed for random array values.
		int arraySize= 10000003; // Size of array to be sorted
		// int maxInt= Integer.MAX_VALUE; // (All random values) % maxInt
		Random rand= new Random(seed);

		System.out.println("MOptimize4. Array size: " + arraySize + ", seed: " + seed);
		// Create four equal arrays b2, c2, d2, and e2*/
		int[] b2= new int[arraySize];
		int[] c2= new int[b2.length];
		Integer[] d2= new Integer[b2.length];
		int[] e2= new int[b2.length];
		for (int k= 0; k < b2.length; k= k + 1) {
			b2[k]= rand.nextInt();
			c2[k]= b2[k];
			d2[k]= b2[k];
			e2[k]= b2[k];
		}

		long startTime;
		long time;

		startTime= System.currentTimeMillis();
		Arrays.sort(c2);
		time= System.currentTimeMillis() - startTime;
		System.out.println(
			"Array length: " + c2.length + ". Time for Arrays.sort (quicksort): " + time +
				" milliseconds");

		startTime= System.currentTimeMillis();
		Arrays.sort(d2);
		time= System.currentTimeMillis() - startTime;
		System.out.println(
			"Array length: " + d2.length + ". Time for TimSort: " + time + " milliseconds");

		startTime= System.currentTimeMillis();
		mergeSort(e2, 0, e2.length - 1);
		time= System.currentTimeMillis() - startTime;
		System.out.println(
			"Array length: " + e2.length + ". Time for mergeSort: " + time + " milliseconds");

		startTime= System.currentTimeMillis();
		mostafaSort(b2, 0, b2.length - 1);
		time= System.currentTimeMillis() - startTime;
		System.out.println(
			"Array length: " + b2.length + ". Time for mostafaSort: " + time + " milliseconds");
	}

	private static int insertionSortBound= 60;

	/** Sort b[h..k]. */
	public static void mostafaSort(int[] b, int h, int k) {
		if (k - h + 1 < insertionSortBound) {// base case
			insertionSort(b, h, k);
			return;
		}
		int n= k + 1 - h;          // size of b[h..k]
		int m= n / 2;
		mostafaSort(b, h, h + m);   // sort b[h..h+m]
		mostafaSort(b, h + m + 1, k);       // sort b[h+m+1..k]
		mostafaMerge(b, h, h + m, k, true);
	}

	/** Merge adjacent sorted sections b[h..g] and b[g+1..k].<br>
	 * If necessary to achieve logarithmic recursion depth, swap the two <br>
	 * sections so that b[g+1..k] is the largest.<br>
	 * Precondition: b[h..g] is nonempty and in ascending order.<br>
	 * . . . . . . . b[g+1..k] is nonempty and is in ascending order if <br>
	 * . . . . . . .isAsc, otherwise descending. Note: Tail-recursive calls are<br>
	 * optimized ——using iteration instead-- using the technique shown in <br>
	 * https://www.cs.cornell.edu/courses/JavaAndDS/files/recursionTail.pdf */
	public static void mostafaMerge(int[] b, int h, int g, int k, boolean isAsc) {
		tailRecursionLoop: while (true) {
			if (handleSimpleBaseCases(b, h, g, k, isAsc)) return;

			int p= g + 1;
			/* Assertion A1
			 *       h-----g-p------------k
			 *    b |  asc  |  asc or des  |
			 *       ----------------------   */

			if (isAsc) reverse(b, p, k); // reverse b[p..k]

			/* Assertion A2:
			*       h-----g-p-----k
			*    b |  asc  |  des  |
			*       ---------------  	 */

			if (k - p < g - h) {  // Swap b[h..g] and b[p..k], if necessary,
				reverse(b, h, k); // so that b[p..k] is the largest.
				g= h + k - p;
				p= g + 1;
			}

			/* Assertion A3: A2 and b[p..k] is larger than b[h..g] */

			// Truthify Assertion A4
			int i= p;
			int j= k;
			int m= g;
			/* loop invariant:
			 *       h-----m-------g---------i-----j---------------k
			 *    b |  asc  |  des  |  asc  |  des  |  asc largest  |
			 *       -----------------------------------------------
			 *    and   b[m+1..i-1] <= b[i..j]
			 *    and   b[h..j] <= b[j+1..k]
			 *    and   h-1 <= m <= g < g+1 <= p < k
			 *    NOTE: b[m+1..g], b[g+1..i-1], and b[j+1..k] are initially empty.	 */
			while (i <= j) {
				if (m < h || b[i] > b[m]) {
					// Note: b[i] is largest value in b[h..j]
					int t= b[i]; // swap b[i] and b[j]
					b[i]= b[j];
					b[j]= t;
					i= i + 1;
					j= j - 1;
				} else {
					// Note: b[m] is largest value in b[h..j]
					int t= b[m]; // swap b[m] and b[j]
					b[m]= b[j];
					b[j]= t;
					m= m - 1;
					j= j - 1;
				}
			}

			/* Assertion A4:
			 *       h-----m-------g-------j---------------k
			 *    b |  asc  |  des  |  asc  |  asc largest  |
			 *       ---------------------------------------
			 *    and   b[h..j] <= b[j+1..k]
			 *    and   h-1 <= m <= g <= j < k
			 */

			// Merge segments b[h..m], b[m+1..g], and b[g+1..j] into
			// one sorted segment to truthify Assertion A6:
			/* Assertion A6:
			*       h-----m---g---j---------------k
			*    b |       asc     |  asc largest  |
			*       -------------------------------
			*    and   b[h..j] <= b[j+1..k]
			*    and   h-1 <= m <= g <= j < k
			*    Therefore, b[h..k] is in ascending order */

			if (twoAreEmpty(b, h, m, g, j, k)) return;

			// handle the case of one section empty
			if (h > m) { // b[h..m] empty
				reverse(b, m + 1, g);
				// tail-recursive call mostafaMerge(b, m + 1, g, j, true);
				h= m + 1;
				k= j;
				isAsc= true;
				continue tailRecursionLoop;
			}
			if (m >= g) {
				// tail-recursive call mostafaMerge(b, h, g, j, true);
				k= j;
				isAsc= true;
				continue tailRecursionLoop;
			}
			if (g >= j) {
				// tail-recursive call mostafaMerge(b, h, m, g, false);
				k= g;
				g= m;
				isAsc= false;
				continue tailRecursionLoop;
			}

			// Handle the case that none are empty.
			// If b[h..m] is the larger of the 3, reverse b[h..g] and change m appropriately
			if (m - (h - 1) > g - m && m - (h - 1) > j - g) {
				reverse(b, h, g);
				m= h + g - m - 1;
			}

			mostafaMerge(b, h, m, g, false);
			// Tail-recursive call mostafaMerge(b, h, g, j, true);
			k= j;
			isAsc= true;
			continue tailRecursionLoop;

		} // end of tailRecursionLoop
	}

	/** Given A4 (above), if two of the sections are empty, do the necessary <br>
	 * to truthify A6 and return true; otherwise, return false. */
	private static boolean twoAreEmpty(int[] b, int h, int m, int g, int j, int k) {
		if (h > m && m >= g) { return true; } // b[h..m] & b[m+1..g] empty. It's sorted
		if (m >= g && g >= j) { return true; } // b[m+1..g] & b[g+1..j] empty. It's sorted.
		if (h > m && g >= j) { // b[h..m] & b[g+1..j] empty. It's reversed
			reverse(b, m + 1, g);
			return true;
		}
		return false;

	}

	/** Parameters and their meanings and properties are as in method mostafaMerge.java. <br>
	 * If b[h..g] and b[g+1..k] can be sorted quickly (using for example just reversals)<br>
	 * and without recursive calls, then do so and return true. Otherwise, return false.<br>
	 * One special case, if b[h..k] has fewer than insertionSortBound values, <br>
	 * insertionSort is used. */
	private static boolean handleSimpleBaseCases(int[] b, int h, int g, int k, boolean isAsc) {
		if (k - h + 1 < insertionSortBound) {
			insertionSort(b, h, k);
			return true;
		}

		if (isAsc && b[g] <= b[g + 1]) {// b[h..g] <= b[g+1..k]
			return true;
		}

		if (!isAsc && b[g] <= b[k]) {// b[h..g] <= b[g+1..k]
			reverse(b, g + 1, k);
			return true;
		}

		if (isAsc && b[h] >= b[k]) { // b[h..g] >= b[g+1..k]
			reverse(b, h, g);
			reverse(b, g + 1, k);
			reverse(b, h, k);
			return true;
		}

		if (!isAsc && b[h] >= b[g + 1]) { // b[h..g] >= b[g+1..k].
			reverse(b, h, g);
			reverse(b, h, k);
			return true;
		}

		return false;
	}

	/** Reverse b[h..k] */
	public static void reverse(int[] b, int h, int k) {
		// inv: b[h..k] remains to be reversed ...
		while (h < k) {
			int t= b[h];
			b[h]= b[k];
			b[k]= t;
			h= h + 1;
			k= k - 1;
		}
	}

	/** Sort b[h..k] --put its elements in ascending order. */
	public static void insertionSort(int[] b, int h, int k) {
		/* inv: h <= j <= k+1 and b[h..j-1] is sorted
		
		            h-----------j----------k
		   inv : b | sorted    |      ?     |
		            ------------------------
		*/
		for (int j= h; j <= k; j++ ) {
			// Sort b[h..j], given that b[h..j-1] is sorted
			int v= b[j];
			int i= j;
			/* inv P: (1) Placing v in b[i] makes b[h..k] a
			              permutation of its initial value
			 (2) b[h..k] with b[i] removed is initial b[h..k-1]
			 (3) v < b[i+1..k]
			 */
			while (i != h && v < b[i - 1]) {
				b[i]= b[i - 1];
				i= i - 1;
			}
			b[i]= v;
		}
	}

	/** Segments b[h..e] and b[e+1..k] are already sorted.<br>
	 * Permute their values so that b[h..k] is sorted. */
	private static void mergeSegments(int b[], int h, int e, int k) {
		int[] c= copy(b, h, e);
		// {c is a copy of original b[h..e]}
		int i= h;
		int j= e + 1;
		int m= 0;
		/* inv: b[h..i-1] contains its final, sorted values
		 * .. . b[j..k] remains to be transferred
		 * .. .  c[m..e-h] remains to be transferred
		 * .. . if they exist, b[i] <= b[j] and b[i] <= c[m]
		*/
		for (i= h; i != k + 1; i++ ) {
			if (j <= k && (m > e - h || b[j] <= c[m])) {
				b[i]= b[j];
				j= j + 1;
			} else {
				b[i]= c[m];
				m= m + 1;
			}
		}
	}

	/** Merge adjacent sorted sections b[h..g] and b[g+1..k]. <br>
	 * Precondition: both are nonempty and sorted. */
	public static void mostafaMergeSimple(int[] b, int h, int g, int k) {
		if (k - h + 1 < insertionSortBound) {
			insertionSort(b, h, k);
			return;
		}

		int p= g + 1;
		/* Assertion A1       h-----g-p-----k
		 *                 b |  asc  |  asc  |
		 *                    ---------------   */

		reverse(b, p, k);

		/* Assertion A2:      h-----g-p-----k
		*                  b |  asc  |  des  |
		*                     ---------------  	 */

		// Truthify Assertion A4
		int i= p;
		int j= k;
		int m= g;
		/* loop invariant:
		 *       h-----m-------g---------i-----j---------------k
		 *    b |  asc  |  des  |  asc  |  des  |  asc largest  |
		 *       -----------------------------------------------
		 *    and   b[m+1..i-1] <= b[i..j]
		 *    and   b[h..j] <= b[j+1..k]
		 *    and   h-1 <= m <= g < g+1 <= p < k
		 *    NOTE: b[m+1..g], b[g+1..i-1], and b[j+1..k] are initially empty.	 */
		while (i <= j) {
			if (m < h || b[i] > b[m]) {
				// Note: b[i] is largest value in b[h..j]
				int t= b[i]; // swap b[i] and b[j]
				b[i]= b[j];
				b[j]= t;
				i= i + 1;
				j= j - 1;
			} else {
				// Note: b[m] is largest value in b[h..j]
				int t= b[m]; // swap b[m] and b[j]
				b[m]= b[j];
				b[j]= t;
				m= m - 1;
				j= j - 1;
			}
		}

		/* Assertion A4:       h-----m-------g-------j---------------k
		 *                  b |  asc  |  des  |  asc  |  asc largest  |
		 *                     ---------------------------------------
		 *            and   b[h..j] <= b[j+1..k]
		 *            and   h-1 <= m <= g <= j < k */

		reverse(b, m + 1, g);

		/* Assertion A5:      h-----m-------g-------j---------------k
		 *                 b |  asc  |  asc  |  asc  |  asc largest  |
		 *                    ---------------------------------------
		 *            and   b[h..j] <= b[j+1..k]
		 *            and   h-1 <= m <= g <= j < k */

		if (m < g && g < j) { mostafaMergeSimple(b, m + 1, g, j); }

		/*  Assertion A6:    h-----m---g---j---------------k
		 *                b |  asc  |  asc  |  asc largest  |
		 *                   -------------------------------
		 *           and   b[h..j] <= b[j+1..k]
		 *           and   h-1 <= m <= g <= j < k */

		if (h <= m && m < j) { mostafaMergeSimple(b, h, m, j); }

		/* Assertion A7:     h--m--g--j---------------k
		 *                b |     asc  |  asc largest  |
		 *                   --------------------------
		 *          and   b[h..j] <= b[j+1..k]
		 *          and   h-1 <= m <= g <= j < k
		 *          Therefore, b[h..k] is in ascending order  */
	}

	/** Sort b[h..k]. */
	public static void mergeSort(int[] b, int h, int k) {
		if (k + 1 - h < insertionSortBound) {
			insertionSort(b, h, k);
			return;
		}

		int e= (h + k) / 2;
		mergeSort(b, h, e);   // Sort b[h..e]
		mergeSort(b, e + 1, k); // Sort b[e+1:k]
		mergeSegments(b, h, e, k); // Merge the 2 segments
	}

	/** Return a copy of array segment b[h..k]. */
	private static int[] copy(int[] b, int h, int k) {
		int[] c= new int[k + 1 - h];
		// inv: b[h..i-1] has been copied to c[0..i-h-1]
		for (int i= h; i != k + 1; i++ ) { c[i - h]= b[i]; }
		return c;
	}

}
