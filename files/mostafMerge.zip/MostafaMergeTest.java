

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.Test;

class MostafaMergeTest {

	@Test
	void testReverse() {
		int[] b= {};
		int[] brev= {};
		MostafaMerge.reverse(b, 0, b.length - 1);
		assertTrue(Arrays.equals(brev, b));

		b= new int[] { 2 };
		brev= new int[] { 2 };
		MostafaMerge.reverse(b, 0, b.length - 1);
		assertTrue(Arrays.equals(brev, b));

		b= new int[] { 2, 3 };
		brev= new int[] { 3, 2 };
		MostafaMerge.reverse(b, 0, b.length - 1);
		assertTrue(Arrays.equals(brev, b));

		b= new int[] { 2, 3, 4 };
		brev= new int[] { 4, 3, 2 };
		MostafaMerge.reverse(b, 0, b.length - 1);
		assertTrue(Arrays.equals(brev, b));

		b= new int[] { 2, 3, 4, 5, 6, 7, 8, 9 };
		brev= new int[] { 9, 8, 7, 6, 5, 4, 3, 2 };
		MostafaMerge.reverse(b, 0, b.length - 1);
		assertTrue(Arrays.equals(brev, b));
	}

	/** Print b. */
	public static void print(int[] b) {
		for (Integer k : b) {
			System.out.print(k + "  ");
		}
		System.out.println();
	}

	@Test
	void test() {
		int[] b1= { 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0 };
		int[] c1= { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
		MostafaMerge.mostafaSort(b1, 0, 15);
		assertEquals(Arrays.toString(c1), Arrays.toString(b1));
		int[] b= { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		int[] c= { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		MostafaMerge.mostafaSort(b, 0, 9);
		assertEquals(Arrays.toString(b), Arrays.toString(c));
	}

	@Test
	void test1() {

		// int[] b2= new int[300001];
		int[] b2= new int[20000766];
		// int[] b2= new int[20000005]; // 103, 501 does not work with press bool
		// int[] b2= new int[605];
		int[] c2= new int[b2.length];
		for (int k= 0; k < b2.length; k= k + 1) {
			b2[k]= (int) (Math.random() * 10001);
			c2[k]= b2[k];
		}
		long begin= System.currentTimeMillis();
		MostafaMerge.mostafaSort(b2, 0, b2.length - 1);
		long elapsed= System.currentTimeMillis() - begin;
		System.out.println("Elapsed time for array of size " + b2.length + ": " + elapsed);

		MostafaMerge.mergeSort(c2, 0, c2.length - 1);
		assertTrue(Arrays.equals(c2, b2));
	}

	@Test
	void test2() {
		// int[] f1= new int[2000001];
		int[] f1= new int[60];
		int[] g1= new int[f1.length];
		for (int k= 0; k < f1.length; k= k + 1) {
			f1[k]= k;
			g1[k]= k;
		}
		MostafaMerge.mostafaSort(f1, 0, f1.length - 1);
		assertEquals(Arrays.toString(g1), Arrays.toString(f1));

		for (int k= 0; k < f1.length; k= k + 1) {
			f1[k]= f1.length - 1 - k;
		}
		MostafaMerge.mostafaSort(f1, 0, f1.length - 1);
		assertEquals(Arrays.toString(g1), Arrays.toString(f1));

	}

}
