/** An instance represents an expression tree. */
public interface ExpTree {
	/** Return the value of this tree. */
	int eval();

	/** Return the preorder of this tree. */
	String preorder();

	/** Return the postorder of this tree. */
	String postorder();

	/** Return the inorder of this tree, with binary ops parenthesized. */
	String inorder();
}
