
import java.awt.Component;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

/** An instance is a labeled ComboBox of integers m..n with a listener. */
public class ComboBoxListener extends Box {
	/**
	 *
	 */
	private static final long serialVersionUID= 1L;

	/** label for combobox. */
	private JLabel label= new JLabel("           ");

	/** comboBox will have numbers m..n. */
	@SuppressWarnings("unused")
	private int m, n;

	/** The comboxBox. */
	JComboBox<Integer> cb;

	/** Constructor: Combox listener with label s, numbers m..n, <br>
	 * set initially to i */
	public ComboBoxListener(String s, int m, int n, int i) {
		super(BoxLayout.Y_AXIS);
		setAlignmentX(Component.LEFT_ALIGNMENT);
		label.setHorizontalAlignment(SwingConstants.LEFT);
		label.setText(s);
		this.m= m;
		this.n= n;

		cb= new JComboBox<>();
		for (int k= m; k <= n; k= k + 1) {
			// System.out.println(k);
			cb.addItem(k);
		}

		cb.setSelectedItem(i);

		add(label);
		add(cb);
	}

	/** Return the number corresponding to the selection. */
	public int selected() {
		return m + cb.getSelectedIndex();
	}

}
