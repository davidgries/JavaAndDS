import java.awt.FlowLayout;
import java.util.Scanner;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/** An instance is the control panel for the maze generation GUI. */
public class Controls extends JPanel {

	private static final long serialVersionUID= 1L;

	/** The turtle on which this Control panel is placed. */
	Turtle turtle;

	/** horizontal box for controls. */
	Box row= new Box(BoxLayout.X_AXIS);

	/** listeners for width and height comboBoxes. */
	ComboBoxListener width, height;

	/** listeners for start x (col) and y (row).<br>
	 * One of these has to be on the boundary. */
	ComboBoxListener startX, startY;

	/** listeners for end x (col) and y (row).<br>
	 * One of these has to be on the boundary. */
	ComboBoxListener endX, endY;

	/** Button to start a new maze generation using the controls. */
	JButton newMaze= new JButton("new maze");

	/** Button to choose a new seed. */
	JButton seed= new JButton("new seed");

	/** Box for new newMaze and new seed moves. */
	Box news= new Box(BoxLayout.Y_AXIS);

	/** Button for making one step in maze. */
	JButton step1= new JButton("one step");

	/** Button for completing the maze. */
	JButton complete= new JButton("Complete");

	/** Box for 1-step and complete moves. */
	Box moves= new Box(BoxLayout.Y_AXIS);

	/** Error labels and Box for them. */
	JLabel errorLabelU= new JLabel("...");
	JLabel errorLabelD= new JLabel("...");
	Box errorBox= new Box(BoxLayout.Y_AXIS);

	/** Button for showing/hiding parents */
	JButton buttonParent= new JButton("No parents");

	/** Box for showing parents. */
	Box parentBox= new Box(BoxLayout.Y_AXIS);

	/** Constructor: Controls on Turtle t */
	public Controls(Turtle t) {
		turtle= t;
		setLayout(new FlowLayout(FlowLayout.LEFT));

		moves.add(step1);
		step1.addActionListener((e) -> { turtle.addOneNode(); });
		moves.add(complete);
		complete.addActionListener((e) -> { turtle.completeTheMaze(); });
		moves.add(new JLabel("   "));
		row.add(moves);

		width= new ComboBoxListener("width", 2, 30, 10);
		row.add(width);

		height= new ComboBoxListener("height", 2, 30, 10);
		row.add(height);

		startX= new ComboBoxListener("start x", 0, 29, 4);
		row.add(startX);

		startY= new ComboBoxListener("start y", 0, 29, 0);
		row.add(startY);

		endX= new ComboBoxListener("end x", 0, 29, 4);
		row.add(endX);

		endY= new ComboBoxListener("end y", 0, 29, 0);
		row.add(endY);

		row.add(Box.createHorizontalGlue());

		parentBox.add(buttonParent);
		parentBox.add(errorLabelU);
		parentBox.add(errorLabelD);
		buttonParent.addActionListener((e) -> { processButtonParentClick(); });

		row.add(parentBox);

		news.add(newMaze);
		news.add(seed);
		row.add(news);

		newMaze.addActionListener((e) -> { processNewMaze(); });
		seed.addActionListener((e) -> { newSeed(); });

		add(row);
	}

	/** Process click of parent button. */
	public void processButtonParentClick() {
		String s= buttonParent.getText();
		if (s.equals("No parents")) {
			buttonParent.setText("parents");
			turtle.processParentButtonClick(true);
		} else {

			buttonParent.setText("No parents");
			turtle.processParentButtonClick(false);
		}
	}

	/** Get a new seed from keyboard and tell turtle about it. */
	public void newSeed() {
		errorLabelU.setText("...");
		errorLabelD.setText("...");
		repaint();
		Scanner sc= new Scanner(System.in);
		System.out.println("Type a seed ---an integer");
		String s= sc.nextLine().trim();
		try {
			int seed= Integer.parseInt(s);
			turtle.newSeed(seed);
			errorLabelU.setText("New seed: ");
			errorLabelD.setText("" + seed);
			sc.close();
		} catch (NumberFormatException n) {
			errorLabelU.setText("Typed seed not");
			errorLabelD.setText("an int. No change");
			sc.close();
			repaint();
			return;
		}
	}

	/** Put su and sd into the error labels */
	public void setLabels(String su, String sd) {
		errorLabelU.setText(su);
		errorLabelD.setText(sd);
	}

	/** Set up a new maze using the values of the ComboboxListeners and start <br>
	 * the maze generation. <br>
	 * Print message and return if values are not proper. */
	public void processNewMaze() {
		setLabels("...", "...");
		repaint();
		int newWidth= width.selected();
		int newHeight= height.selected();

		int sX= startX.selected();
		int sY= startY.selected();
		int eX= endX.selected();
		int eY= endY.selected();

		if (sX >= newWidth) {
			setLabels("start x is too big.", "Must be in 0.." + (newWidth - 1));
			return;
		}

		if (sY >= newHeight) {
			setLabels("start y is too big.", "Must be in 0.." + (newHeight - 1));
			return;
		}

		if (0 < sX && sX < newWidth - 1 && 0 < sY && sY < newHeight - 1) {
			setLabels("put start x or start y", "on boundary.");
			return;
		}

		if (eX >= newWidth) {
			setLabels("end x is too big.", "Must be in 0.." + (newWidth - 1));
			return;
		}

		if (eY >= newHeight) {
			setLabels("end y is too big.", "Must be in 0.." + (newHeight - 1));
			return;
		}

		if (0 < eX && eX < newWidth - 1 && 0 < eY && eY < newHeight - 1) {
			setLabels("put end x or end y", "on boundary");
			return;
		}

		if (sX == eX && sY == eY) {
			setLabels("Start and end", "must be different");
			return;
		}

		turtle.processNewMaze(newWidth, newHeight, sX, sY, eX, eY);
	}

}
