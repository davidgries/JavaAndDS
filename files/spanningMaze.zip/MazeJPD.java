import java.util.ArrayList;
import java.util.Random;

/** An instance contains Prim's algorithm for contructing a maze.
 * 
 * @Author - David Gries */
public class MazeJPD {

	/** The maze is of size (width, height). */
	private int width;
	private int height;

	/* maze defines the complete graph and also the spanning
	 * tree as it is being constructed.
	 *
	 * The grid has upper left (0, 0). x goes across, y goes down.
	 *
	 * The nodes of the graph are the entries in maze, as laid out on a grid.
	 * A node at (x, y) has edges leaving it to the nodes in all four directions:
	 *         N (x, y-1), and E (y+1, c), W (x-1, y), S (x, y+1),
	 * There is no need to have a data structure representing all edges because
	 * of the above.
	 *
	 * Exactly one node has value b: it is the start node. It is in
	 * spanning tree Cb.
	 * A node with value N (E, W, or S) is in Cb. It neighbor on the spanning-tree
	 * edge constructed when it was added to Cb is to the North (East, West, or South).
	 * Considering b to be the root, N, E, W, or S is the parent of the node, the
	 * backpointer.
	 *
	 * A node has value F iff it is not in Cb and at least one of its neighbors
	 * is in Cb. ArrayList F contains all nodes with value F.
	 *
	 * All other nodes are not in Cw or F; they have value O.
	 */
	public NodeType[][] maze;
	public ArrayList<Point> F= new ArrayList<>();

	Random rand; // The random number generator used

	/** A maze of size (w, h) with start node (x, y).<br>
	 * Random-number generation starts with seed seed. */
	public MazeJPD(int w, int h, int x, int y, int seed) {
		rand= new Random(seed);
		width= w;
		height= h;
		maze= new NodeType[width][height];
		// Place all nodes in the other group --not in Cw or F
		for (int r= 0; r < maze.length; r= r + 1) {
			for (int c= 0; c < maze[0].length; c= c + 1) maze[r][c]= NodeType.O;
		}

		maze[x][y]= NodeType.b;
		addToF(x, y);
	}

	/** Make one step of the JPD algorithm:<br>
	 * Choose a random node v in F and then a random edge (v, u) <br>
	 * with u in spanning tree Cb.<br>
	 * Change v to be in Cb and fix F to satisfy its invariant.<br>
	 * Edge (v, u) is now considered to be an edge of the spanning tree.<br>
	 * Return the new node v that was added to Cb */
	public Point JPDStep() {
		// Get the next random node in v and remove it from F in O(1) time.
		int size= F.size();
		int num= rand.nextInt(size);
		Point v= F.get(num);
		F.set(num, F.get(size - 1));
		F.remove(size - 1);

		// Determine the edge (u, v) to add, thus also finding v
		ArrayList<Point> inCb= neighbors(v, maze); // neighbors of u that are in Cw
		num= rand.nextInt(inCb.size());
		Point u= inCb.get(num);

		// Put v into Cb by setting the direction for edge from v to u
		NodeType dir= direction(v, u);
		maze[v.x][v.y]= dir;

		// Add to F neighbors of v that are not in Cb or F
		addToF(v.x, v.y);

		return v;
	}

	/** Return the direction from v to u. */
	public NodeType direction(Point v, Point u) {
		if (v.x < u.x) return NodeType.E;
		if (v.x > u.x) return NodeType.W;
		if (v.y < u.y) return NodeType.S;
		return NodeType.N;
	}

	/** Return a list of neighbors of u that are in spanning tree Cb. <br>
	 * Precondition: u is in the maze */
	public ArrayList<Point> neighbors(Point u, NodeType[][] maze) {
		ArrayList<Point> ns= new ArrayList<>();
		int x= u.x;
		int y= u.y;
		if (0 < y && maze[x][y - 1] != NodeType.F && maze[x][y - 1] != NodeType.O)
			ns.add(new Point(x, y - 1)); // North
		if (x + 1 < maze.length && maze[x + 1][y] != NodeType.F && maze[x + 1][y] != NodeType.O)
			ns.add(new Point(x + 1, y)); // East
		if (0 < x && maze[x - 1][y] != NodeType.F && maze[x - 1][y] != NodeType.O)
			ns.add(new Point(x - 1, y)); // West
		if (y + 1 < maze[x].length && maze[x][y + 1] != NodeType.F && maze[x][y + 1] != NodeType.O)
			ns.add(new Point(x, y + 1)); // South
		return ns;
	}

	/** Precondition: Node (r, c) is in spanning tree Cb.<br>
	 * Add to F all edges {(r, c), v} with v not in F or Cw. */
	public void addToF(int r, int c) {
		addToF(r - 1, c, maze, F); // West
		addToF(r, c + 1, maze, F); // South
		addToF(r, c - 1, maze, F); // North
		addToF(r + 1, c, maze, F); // East
	}

	/** Add node (r, c) to F if it is in the maze and is not in Cb or F. */
	public void addToF(int r, int c, NodeType[][] maze, ArrayList<Point> F) {
		if (0 <= r && r < maze.length && 0 <= c &&
			c < maze[r].length && maze[r][c] == NodeType.O) {
			maze[r][c]= NodeType.F;
			F.add(new Point(r, c));
		}
	}

	/** Return maze, one column per line */
	public String print(NodeType[][] maze) {
		String s= "";
		for (int c= 0; c < maze[0].length; c= c + 1) {
			for (int r= 0; r < maze.length; r= r + 1) {
				s= s + maze[r][c];
			}
			s= s + '\n';
		}
		return s;
	}

}
