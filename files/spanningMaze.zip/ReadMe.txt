Use this application to learn about using a version of Prim's algorithm
for constructing a spanning tree to construct a maze.

The controls to define the (width, height) of the maze, the start position 
of the maze, and the end position of the maze are all at the top of the GUI.

In addition one can specify whether the maze has nothing in each node or whether
it shows the parent links, with the start node ('b') being the root of the
spanning tree that is generated. And, one can specify through the keyboard
the seed used in generated in generated the maze.

The start and end nodes must be on edges of the maze.

When generating a maze, one can have it generate one node of the spanning tree
at a time ("one step") or complete the maze without interruption ("Complete").

Class MazeTurtle contains method main and is thus the application.

Class MazeJPD contains the actual methods that generate the maze.
Method JPDStep() generates one node of the spanning tree.

Enum NodeType contains the possible entries in a node of the graph.

The rest of the classes are used in developing the GUI.

David Gries

