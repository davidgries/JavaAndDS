
/** Maze generation. */
import java.awt.Color;

/** An instance contains methods to draw a maze. */
public class MazeTurtle extends Turtle {

	/** Width and height of the maze. */
	private int wdth= 15, hght= 15;

	/** Seed to use in random generation. */
	private int seed= 9;

	/** Start node. */
	private int xStart= 0, yStart= 8;

	/** End node. */
	private int xEnd= 0, yEnd= hght - 4;

	/** Width of a line. Always odd. */
	private final int wLine= 5; // DO NOT CHANGE

	/** wdth, hght of a square. Keep odd. */
	private final int wSquare= 15, hSquare= 15; // DO NOT CHANGE

	/** put parent links in GUI iff true. */
	private boolean putParentLinks= false;

	/** The maze model being used. */
	MazeJPD m;

	public static void main(String[] args) {
		MazeTurtle mt= new MazeTurtle();
		mt.setPanelSize();
		mt.processNewMaze(mt.wdth, mt.hght, mt.xStart, mt.yStart, mt.xEnd, mt.yEnd);
		mt.startMaze();
	}

	/** Process a click of "new Maze" button in the Control panel. <br>
	 * Precondition: no errors in the controls. <br>
	 * Parameters are: width and height of maze, start point (xS, yS), and end point (xE, yE) */
	@Override
	public void processNewMaze(int wdth, int hght, int xS, int yS, int xE, int yE) {
		this.wdth= wdth;
		this.hght= hght;
		xStart= xS;
		yStart= yS;
		xEnd= xE;
		yEnd= yE;
		m= new MazeJPD(wdth, hght, xStart, yStart, seed);
		startMaze();
	}

	/** Set the new seed to n. */
	@Override
	public void newSeed(int n) {
		seed= n;
	}

	/** Start a new maze generation. */
	public void startMaze() {
		clear();  // Set whole panel to white.

		// Blacken the maze
		setColor(Color.black);
		int totalWidth= wdth * (wLine + wSquare) + wLine;
		int totalHeight= hght * (wLine + hSquare) + wLine;
		moveTo(totalWidth / 2, totalHeight / 2, 0);
		fillRectangle(totalWidth, totalHeight);

		// Draw the start and end squares
		setColor(Color.white);
		colorSquare(xStart, yStart);
		placeChar('b', xStart, yStart, 4, 2);
		colorStartEndBorder(xStart, yStart);
		colorSquare(xEnd, yEnd);
		placeChar('e', xEnd, yEnd, 15, 2);
		colorStartEndBorder(xEnd, yEnd);

		yellowTheFrontier();
		setColor(Color.white);
	}

	/** Generate next node of the maze. */
	@Override
	public void addOneNode() {
		if (0 == m.F.size()) {
			controls.setLabels("maze is done", "");
			return;
		}
		JPDIteration(m);
	}

	/** Complete the maze. */
	@Override
	public void completeTheMaze() {
		while (0 < m.F.size()) {
			JPDIteration(m);
		}
		controls.setLabels("maze is done", "...");
	}

	/** Set a field to indicate that parent arrows are to be shown if b is true. */
	@Override
	public void processParentButtonClick(boolean b) {
		putParentLinks= b;
	}

	/** Make the frontier yellow. */
	public void yellowTheFrontier() {
		setColor(Color.YELLOW);
		for (Point p : m.F) {
			colorSquare(p.x, p.y);
		}
	}

	/** Do one iteration of the JPD algorithm */
	public void JPDIteration(MazeJPD m) {
		Point p= m.JPDStep();

		setColor(Color.white);
		colorSquare(p.x, p.y);
		whitenLine(p.x, p.y, m);
		PlaceBkPtr(p.x, p.y, m);
		yellowTheFrontier();
	}

	/** Place the backpointer in node p. */
	public void PlaceBkPtr(int x, int y, MazeJPD m) {
		if (m.maze[x][y] == NodeType.N) placeChar('↑', x, y, 5, 5);
		if (m.maze[x][y] == NodeType.E) placeChar('→', x, y, 2, 1.8);
		if (m.maze[x][y] == NodeType.W) placeChar('←', x, y, -2, 1.8);
		if (m.maze[x][y] == NodeType.S) placeChar('↓', x, y, 5, 1);
	}

	/** Fill in line between new point (x, y) and its neighbor. */
	public void whitenLine(int x, int y, MazeJPD m) {
		if (m.maze[x][y] == NodeType.N) colorHorizontal(x, y);
		if (m.maze[x][y] == NodeType.E) colorVertical(x + 1, y);
		if (m.maze[x][y] == NodeType.W) colorVertical(x, y);
		if (m.maze[x][y] == NodeType.S) colorHorizontal(x, y + 1);

	}

	/** Color square (x, y) in mt with current color. */
	public void colorSquare(int x, int y) {
		int xUpperLeft= x * (wLine + wSquare) + wLine;
		int yUpperLeft= y * (wLine + hSquare) + wLine;
		moveTo(xUpperLeft + wSquare / 2, yUpperLeft + hSquare / 2, 0);
		fillRectangle(wSquare, hSquare);
	}

	/** Color horizontal line above square (x, y) with current color */
	public void colorHorizontal(int x, int y) {
		int xUpperLeft= x * (wLine + wSquare) + wLine;
		int yUpperLeft= y * (wLine + hSquare);
		moveTo(xUpperLeft + 3 * wLine / 2, yUpperLeft + wLine / 2, 0);
		fillRectangle(hSquare, wLine);
	}

	/** Color vertical line to left of square (x, y) with current color */
	public void colorVertical(int x, int y) {
		int xUpperLeft= x * (wLine + wSquare);
		int yUpperLeft= y * (wLine + hSquare) + wLine;
		moveTo(xUpperLeft + wLine / 2, yUpperLeft + 3 * wLine / 2, 0);
		fillRectangle(wLine, hSquare);
	}

	/** Color vertical/horizontal line above/left of square(x, y) with current color. */
	public void colorBox(int x, int y) {
		int xUpperLeft= x * (wLine + wSquare);
		int yUpperLeft= y * (wLine + hSquare);
		moveTo(xUpperLeft + wLine / 2, yUpperLeft + wLine / 2, 0);
		fillRectangle(wLine, wLine);
	}

	/** Place character c in square (x, y) in with current color. <br>
	 * Move it across mt.wSquare / x1 and down mt.hSquare / y1 <br>
	 * Note: if c is 'b' or 'e', ALWAYS do this. <br>
	 * Otherwise, do this only if putParentLinks is true. */
	public void placeChar(char c, int x, int y, double x1, double y1) {
		if (c != 'b' && c != 'e' && !putParentLinks) return;
		int xUpperLeft= x * (wLine + wSquare);
		int yUpperLeft= y * (wLine + hSquare) + wLine;
		moveTo(xUpperLeft + wLine + wSquare / x1, yUpperLeft + wLine + hSquare / y1,
			0);
		drawString("" + c);
	}

	/** if (x, y) is on a border, color stuff between square and border with current color */
	public void colorStartEndBorder(int x, int y) {
		if (x == 0) colorVertical(x, y);
		if (y == 0) colorHorizontal(x, y);
		if (x == 0 && y == 0) colorBox(x, y);

		if (y == hght - 1) colorHorizontal(x, y + 1);
		if (x == 0 && y == hght - 1) colorBox(x, y + 1);

		if (x == wdth - 1) colorVertical(x + 1, y);
		if (x == wdth - 1 && y == 0) colorBox(x + 1, y);

		if (x == wdth - 1 && y == hght - 1) colorBox(x + 1, y + 1);
	}
}
