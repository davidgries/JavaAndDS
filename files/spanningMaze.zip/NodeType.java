/** Description of a node in the graph.<br>
 * If it's in spanning tree Cb,<br>
 * tells whether it's b or gives direction of spanning tree edge. */
public enum NodeType {
	/** start node, in spanning tree */
	b,
	/** in spanning tree. parent to the North. */
	N,
	/** in spanning tree. parent to the East. */
	E,
	/** in spanning tree. parent to the West. */
	W,
	/** in spanning tree. parent to the South. */
	S,
	/** Adjacent to spanning tree. In frontier F. */
	F,
	/** Not (in spanning tree or adjacent to spanning tree) */
	O
}