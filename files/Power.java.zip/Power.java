/** Contains static methods to help analyze functions to compute b^n. */
public class Power {
    /*  The algorithms given below to calculate b^n uses the binary representation
     *  of n in the following way. Consider
     *     2^4   = 16: in binary:  1000
     *     2^4-1 = 15: in binary:   111
     *
     *  A recursive call look at the last bit of n
     *  If that bit is 0, n is even, and the next recursive call uses
     *     n/2 --that's n with the last bit thrown away.
     *  If that bit is 1, n is odd, and the next recursive call uses
     *     n-1  --that's n with its last bit changed from 1 to 0.
     *  So, the number of recursive calls is at most 2 times the
     *     number of bits needed to represent n in binary.
     */

    /** = b^n<br>
     * Precondition: n >= 0. */
    public static double iterativePow(double b, int n) {
        double x= b;
        int y= n;
        double z= 1.0;
        // invariant P: y >= 0 and b^n = z*x^y
        while (y != 0) {
            if (y % 2 != 0) {
                z= z * x;
                y= y - 1;
            } else {
                x= x * x;
                y= y / 2;
            }
        }
        return z;
    }

    /*  b: 2.0
     *  n: 2
     *  x: 2.0   4.0
     *  y: 2       1
     *  z: 1.0
     */

    /** = b^n. Precondition n >= 0. <br>
     * Properties: b^0 = 1.<br>
     * ........... b^n = b*b^(n-1) for n > 0. */
    public static double powSlow(double b, int n) {
        if (n == 0) { return 1; }
        return b * powSlow(b, n - 1);
    }

    /** = b^n. <br>
     * Precondition n >= 0. <br>
     * Properties: b^0 = 1. <br>
     * ........... b^n = b*b^(n-1) for n > 0.<br>
     * ........... b^n = (b*b)^(n/2) for even n. <br>
     * ........... e.g. 3*8 = 3*3*3*3*3*3*3*3 = (3*3) * (3*3) * (3*3) * (3*3) = (3*3)^4 */
    public static double powFast(double b, int n) {
        if (n == 0) { return 1; }
        if (n % 2 == 0) { return powFast(b * b, n / 2); }
        return b * powFast(b, n - 1);
    }

    // The following method produce a pair
    // (value of b^c, number of calls made to produce the value)
    // They use class PairDi to aggregate the two values into an object.
    // We could say that the object wraps the two values.

    /** = the pair (b^n, no. of calls made). <br>
     * Precondition: n ≥ 0 */
    public static PairDI pow1Fast(double b, int n) {
        if (n == 0) return new PairDI(1.0, 1);

        // n > 0
        if (n % 2 == 0) {
            PairDI p= pow1Fast(b * b, n / 2);
            return new PairDI(p.d, p.i + 1);
        }

        // n is odd
        PairDI p= pow1Fast(b, n - 1);
        return new PairDI(b * p.d, p.i + 1);
    }

    /** Print how big the call-stack can get, using pow1Slow Then print how big the call stack is
     * for pow1Fast. */
    public static void main(String[] args) {
        int k= 1;
        double a= 0;
        try {
            while (true) {
                a= powSlow(.9999, k);
                k= 2 * k;
            }
        } catch (StackOverflowError re) {}
        System.out.println("powSlow(.9999, " + k + ") overflowed the call stack.");
        a= powSlow(.9999, k / 2);
        System.out.println("powSlow(.9999, " + k / 2 + ") was " + a);
        PairDI fast= pow1Fast(.9999, k / 2);
        System.out.println("pow1Fast(.9999, " + k / 2 + ") was " + fast.d +
            ". Recursion depth: " + fast.i);
        fast= pow1Fast(.9999, k);
        System.out.println("pow1Fast(.9999, " + k + ") was " + fast.d +
            ". Recursion depth: " + fast.i);

        fast= pow1Fast(.9999, k - 1);
        System.out.println("pow1Fast(.9999, " + (k - 1) + ") was " + fast.d +
            ". Recursion depth: " + fast.i);
    }

    /** An instance contains a pair of values, one double and one int */
    static class PairDI {
        public double d;
        public int i;

        public PairDI(double dd, int ii) {
            d= dd;
            i= ii;
        }
    }
}
