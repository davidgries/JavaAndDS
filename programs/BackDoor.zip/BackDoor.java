/** This class illustrates that a thread can use the back door and change <br>
 * a variable even though another thread has synchronized on that variable. */
public class BackDoor implements Runnable {
	static Integer y= 2;

	public static void main(String args[]) {
		Runnable r= new BackDoor();
		new Thread(r).start();
		m();
		System.out.println("Ending. y is: " + y);
	}

	/** Add 1 to y, synchronizing on y to do it.<br>
	 * Print a message when starting, after waking up, and after changing y. */
	public static void m() {
		synchronized (y) {
			System.out.println("m starting; it's synchronized on y");
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				System.out.println("run-sleep interrupted");
			}
			System.out.println("m woke up; it's synchronized on y");
			y= y + 1;
			System.out.println("m added 1 to y. m releasing the lock");
		}
	}

	/** Sleep for 1 second, then set y to -100. <br>
	 * Print a message when starting, after waking up, and after changing y. */
	public @Override void run() {
		System.out.println("run starting");
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			System.out.println("run-sleep interrupted");
		}
		System.out.println("run woke up");
		synchronized (y) {
			y= -100;
		}
		System.out.println("run: y set to -100");
	}

}
