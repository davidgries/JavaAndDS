import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;


public class TimeTester {
   /** Method tests using java.util.sort to sort an array of class Time. */
    @Test
    public void testSorting() {
        Time[]b= new Time[] {
                new Time(20, 5),
                new Time(10,50),
                new Time(5, 0),
                new Time(0, 4),
                new Time(0, 1)};
        java.util.Arrays.sort(b);
        assertEquals("00:01", b[0].toString());
        assertEquals("00:04", b[1].toString());
        assertEquals("05:00", b[2].toString());
        assertEquals("10:50", b[3].toString());
        assertEquals("20:05", b[4].toString());
    }

}
